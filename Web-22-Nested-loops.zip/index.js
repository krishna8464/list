
// // for(let f = 1;f<=4;f++){
// //  let bag = "";
// //   let bag2 = "";
// //   for(let s=1;s<=f;s++){
// //     bag2 = bag2 + s
// //     bag=bag + "*"
// //   }
// //   console.log(bag2)
// //   console.log(bag)
// // }
// You are given an array of N integers. You need to printYesif 42 is present in array, else printNo
var father=1;
while(father<=16)
{
var son=1;
var bag = "";
while(son<=10)
{
bag=bag+"*";
son++;
}
console.log(bag);
father++;
}

